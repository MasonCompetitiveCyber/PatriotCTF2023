<footer class="footer-banner">
    <p>Nothing to see here... I promise</p>
</footer>
</body>
</html>
