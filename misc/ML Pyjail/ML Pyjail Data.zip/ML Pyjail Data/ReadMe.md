## ML Pyjail

> Make sure to give `entrypoint.sh` executable file permission

```shell
docker-compose up
```
#### Linux

```shell
netcat localhost 4444
```

#### Windows
```powershell
ncat.exe localhost 4444
```