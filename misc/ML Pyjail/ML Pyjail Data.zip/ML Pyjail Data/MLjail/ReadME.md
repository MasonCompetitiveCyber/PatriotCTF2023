```
pip install numpy
```

```
pip install pandas
```

```
pip install nltk
```

```
pip install tensorflow==2.9.1
```

```
pip install tflearn
```

